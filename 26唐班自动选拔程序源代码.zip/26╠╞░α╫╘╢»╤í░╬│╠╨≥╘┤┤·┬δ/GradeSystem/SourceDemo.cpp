#include<iostream>
#include<cstring>
using namespace std;
class Math{
	public:
		string id;
		int math_Score;
		int physics_Score;
		int english_Score;
		int all_Score;
		int view_Score;
		int view_English;
		int view_All;
	
		Math(string i="000000000",int m=0,int p=0,int e=0,int vs=0,int ve=0){
		id=i;
		math_Score=m;
		physics_Score=p;
		english_Score=e;
		all_Score=math_Score+physics_Score+english_Score;
		view_Score=vs;
		view_English=ve;
		view_All=view_Score+view_English;
		}
};
class Physics{
	public:
		string id;
		int physics_Score;
		int math_Score;
		int english_Score;
		int all_Score;
		int view_Score;
		int view_English;
		int view_All;
		
		Physics(string i="000000000",int p=0,int m=0,int e=0,int vs=0,int ve=0){
		id=i;
		physics_Score=p;
		math_Score=m;
		english_Score=e;
		all_Score=physics_Score+math_Score+english_Score;
		view_Score=vs;
		view_English=ve;
		view_All=view_Score+view_English;		
		}
};
class Chemist:public Student{
	public:
		string id;
		int chemist_Score;
		int biology_Score;
		int math_Score;
		int english_Score;
		int all_Score;
		int view_Score;
		int view_English;
		int view_All;
		
		Chemist(string i="000000000",int c=0,int b=0,int m=0,int e=0;int a=0,int vs=0,int ve=0){
		id=i;
		chemist_Score=c;
		biology_Score=b;
		math_Score=m;
		english_Score=e;
		all_Score=chemist_Score+biology_Score+math_Score+english_Score;
		view_Score=vs;
		view_English=ve;
		view_All=view_Score+view_English;	
		}
};
class Biology:public Student{
	public:
		string id;
		int chemist_Score;
		int biology_Score;
		int math_Score;
		int english_Score;
		int all_Score;
		int view_Score;
		int view_English;
		int view_All;
		
		Biology(string i="000000000",int c=0,int b=0,int m=0,int e=0,int vs=0,int ve=0){
			id=i;
			chemist_Score=c;
			biology_Score=b;
			math_Score=m;
			english_Score=e;
			all_Score=chemist_Score+biology_Score+math_Score+english_Score;
			view_Score=vs;
			view_English=ve;
			view_All=view_Score+view_English;
		}
}; 
class Computer:public Student{
	public:
		string id;
		int computer_Score;
		int math_Score;
		int physics_Score;
		int english_Score;
		int all_Score;
		int view_Score;
		int view_English; 
		int view_All;
		
		Computer(string i="000000000",int c=0,int m=0,int p=0,int e=0,int vs=0,int ve=0){
		id=i;
		computer_Score=c;
		math_Score=m;
		physics_Score=p;
		english_Score=e;
		all_Score=computer_Score+math_Score+physics_Score+english_Score;
		view_Score=vs;
		view_English=ve; 
		view_All=view_Score+view_English;
		}
};
