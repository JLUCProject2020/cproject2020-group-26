#ifndef VIEWBIOLOGY_H
#define VIEWBIOLOGY_H

#include <QWidget>

class ViewBiology : public QWidget
{
    Q_OBJECT
public:
    explicit ViewBiology(QWidget *parent = nullptr);

signals:

public slots:
};

#endif // VIEWBIOLOGY_H