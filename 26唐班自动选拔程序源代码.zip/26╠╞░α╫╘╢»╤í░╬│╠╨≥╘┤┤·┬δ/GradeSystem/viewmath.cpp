#include "viewmath.h"
#include"source.h"
#include<QLabel>
#include<QLineEdit>
#include<QString>
#include<QDebug>
#include<QPushButton>
#include<QDialog>

ViewMath::ViewMath(QWidget *parent) : QWidget(parent)
{
    setFixedSize(1200,800);
    setWindowTitle("面试数学");

    QLabel * title = new QLabel;
    title->setParent(this);
    title->setText("数学");
    title->move(20,30);
    QLabel * lab1 = new QLabel;
    lab1->setParent(this);
    lab1->setText("学号：");
    lab1->move(20,50);
    QLabel * lab2 = new QLabel;
    lab2->setParent(this);
    lab2->setText("综合面试分数：");
    lab2->move(20,100);
    QLabel * lab3 = new QLabel;
    lab3->setParent(this);
    lab3->setText("英语面试分数：");
    lab3->move(20,200);


    QLineEdit * idnum = new QLineEdit;
    idnum->setParent(this);
    idnum->move(130,50);
    QLineEdit * mathnum = new QLineEdit;
    mathnum->setParent(this);
    mathnum->move(130,100);
    QLineEdit * engnum = new QLineEdit;
    engnum->setParent(this);
    engnum->move(130,200);


    QPushButton * btn1 = new QPushButton;
    btn1->setParent(this);
    btn1->setText("下一个");
    btn1->move(800,700);
    QPushButton * btn2 = new QPushButton;
    btn2->setParent(this);
    btn2->setText("结束");
    btn2->move(950,700);


    Math* mathstudent = new Math[10];
    static int k=0;

    QDialog * dlg1 = new QDialog(this);
    dlg1->hide();
    dlg1->resize(500,500);
    QLabel * res1 = new QLabel(dlg1);
    res1->move(20,30);
    QLabel * res2 = new QLabel(dlg1);
    res2->move(20,60);
    QLabel * res3 = new QLabel(dlg1);
    res3->move(20,90);
    QLabel * res4 = new QLabel(dlg1);
    res4->move(20,120);
    QLabel * res5 = new QLabel(dlg1);
    res5->move(20,150);
    QLabel * res6 = new QLabel(dlg1);
    res6->move(20,180);
    QLabel * res7 = new QLabel(dlg1);
    res7->move(20,210);
    QLabel * res8 = new QLabel(dlg1);
    res8->move(20,240);
    QLabel * res9 = new QLabel(dlg1);
    res9->move(20,270);
    QLabel * res10 = new QLabel(dlg1);
    res10->move(20,300);

    connect(btn1,&QPushButton::clicked,[=](){
        int str1 = idnum->text().toInt();
        qDebug()<<str1;
        int str2 = mathnum->text().toInt();
        int str3 = engnum->text().toInt();

        mathstudent[k].id=str1;
        mathstudent[k].view_Score=str2;
        mathstudent[k].view_English=str3;
        mathstudent[k].view_All=str2+str3;
        k++;

        idnum->setText(NULL);
        mathnum->setText(NULL);
        engnum->setText(NULL);
    });

    connect(btn2,&QPushButton::clicked,[=](){
        int h,j,temp;
        for(h=0;h<k-1;h++)
            for(j=0;j<k-h-1;j++){
                if(mathstudent[j].view_All>mathstudent[j+1].view_All){
                    temp=mathstudent[j].view_All;
                    mathstudent[j].view_All=mathstudent[j+1].view_All;
                    mathstudent[j+1].view_All=temp;
                    temp=mathstudent[j].id;
                    mathstudent[j].id=mathstudent[j+1].id;
                    mathstudent[j+1].id=temp;
                }
            }

        for(h=0;h<k;h++){
            switch (h) {
            case 1:
                res1->setText(QString::number(mathstudent[h].id));
                break;
            case 2:
                res2->setText(QString::number(mathstudent[h].id));
                break;
            case 3:
                res3->setText(QString::number(mathstudent[h].id));
                break;
            case 4:
                res4->setText(QString::number(mathstudent[h].id));
                break;
            case 5:
                res5->setText(QString::number(mathstudent[h].id));
                break;
            case 6:
                res6->setText(QString::number(mathstudent[h].id));
                break;
            case 7:
                res7->setText(QString::number(mathstudent[h].id));
                break;
            case 8:
                res8->setText(QString::number(mathstudent[h].id));
                break;
            case 9:
                res9->setText(QString::number(mathstudent[h].id));
                break;
            case 10:
                res10->setText(QString::number(mathstudent[h].id));
                break;
            default:
                break;
            }

        }
        dlg1->show();
    });
}
