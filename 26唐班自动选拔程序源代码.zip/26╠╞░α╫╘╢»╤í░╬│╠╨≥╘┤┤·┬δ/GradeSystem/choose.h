#ifndef CHOOSE_H
#define CHOOSE_H

#include <QWidget>
#include"bishi.h"
#include"mianshi.h"

class Choose : public QWidget
{
    Q_OBJECT
public:
    explicit Choose(QWidget *parent = nullptr);
    BiShi * bishi = NULL;
    MianShi * mianshi = NULL;


signals:

public slots:
};

#endif // CHOOSE_H
