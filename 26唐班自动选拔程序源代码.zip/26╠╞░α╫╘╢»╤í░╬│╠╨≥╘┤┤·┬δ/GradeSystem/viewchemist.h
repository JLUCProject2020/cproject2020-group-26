#ifndef VIEWCHEMIST_H
#define VIEWCHEMIST_H

#include <QWidget>

class ViewChemist : public QWidget
{
    Q_OBJECT
public:
    explicit ViewChemist(QWidget *parent = nullptr);

signals:

public slots:
};

#endif // VIEWCHEMIST_H