#ifndef VIEWPHYSICS_H
#define VIEWPHYSICS_H

#include <QWidget>

class ViewPhysics : public QWidget
{
    Q_OBJECT
public:
    explicit ViewPhysics(QWidget *parent = nullptr);

signals:

public slots:
};

#endif // VIEWPHYSICS_H