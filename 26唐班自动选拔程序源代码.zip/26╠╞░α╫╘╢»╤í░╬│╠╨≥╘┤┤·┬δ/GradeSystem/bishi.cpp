#include "bishi.h"
#include<QPushButton>
#include"widget.h"


BiShi::BiShi(QWidget *parent) : QWidget(parent)
{
    setFixedSize(1200,800);
    setWindowTitle("笔试");
    QPushButton * math = new QPushButton;
    QPushButton * chemist = new QPushButton;
    QPushButton * computer = new QPushButton;
    QPushButton * physic = new QPushButton;
    QPushButton * biology = new QPushButton;
    QPushButton * back = new QPushButton;
    math->setParent(this);
    math->setText("数学");
    math->resize(400,150);
    chemist->setParent(this);
    chemist->setText("化学");
    chemist->resize(400,150);
    computer->setParent(this);
    computer->setText("计算机");
    computer->resize(400,150);
    physic->setParent(this);
    physic->setText("物理");
    physic->resize(400,150);
    biology->setParent(this);
    biology->setText("生物");
    biology->resize(400,150);
    back->setParent(this);
    back->setText("打印成绩并返回");
    back->resize(400,150);

    math->move(70,50);
    chemist->move(70,300);
    computer->move(70,550);
    physic->move(700,50);
    biology->move(700,300);
    back->move(700,550);


    wribio = new WriBio;
    wrichem = new WriChem;
    wricompu = new WriCompu;
    wrimath = new WriMath;
    wriphy = new WriPhy;

    connect(math,&QPushButton::clicked,[=](){
        this->hide();
        wrimath->show();
    });

    connect(chemist,&QPushButton::clicked,[=](){
        this->hide();
        wrichem->show();
    });

    connect(computer,&QPushButton::clicked,[=](){
        this->hide();
        wricompu->show();
    });

    connect(physic,&QPushButton::clicked,[=](){
        this->hide();
        wriphy->show();
    });

    connect(biology,&QPushButton::clicked,[=](){
        this->hide();
        wribio->show();
    });




}
