#ifndef MIANSHI_H
#define MIANSHI_H

#include <QWidget>
#include"viewbiology.h"
#include"viewchemist.h"
#include"viewcomputer.h"
#include"viewmath.h"
#include"viewphysics.h"

class MianShi : public QWidget
{
    Q_OBJECT
public:
    explicit MianShi(QWidget *parent = nullptr);

    ViewBiology * viewbiology = NULL;
    ViewChemist * viewchemist = NULL;
    ViewComputer * viewcomputer = NULL;
    ViewMath * viewmath = NULL;
    ViewPhysics * viewphysics = NULL;

signals:

public slots:
};

#endif // MIANSHI_H
