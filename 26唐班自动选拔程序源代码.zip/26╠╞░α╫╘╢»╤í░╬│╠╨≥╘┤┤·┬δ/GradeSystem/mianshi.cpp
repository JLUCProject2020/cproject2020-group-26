#include "mianshi.h"
#include<QPushButton>

MianShi::MianShi(QWidget *parent) : QWidget(parent)
{
    setFixedSize(1200,800);
    setWindowTitle("面试");
    QPushButton * math = new QPushButton;
    QPushButton * chemist = new QPushButton;
    QPushButton * computer = new QPushButton;
    QPushButton * physic = new QPushButton;
    QPushButton * biology = new QPushButton;
    QPushButton * back = new QPushButton;
    math->setParent(this);
    math->setText("数学");
    math->resize(400,150);
    chemist->setParent(this);
    chemist->setText("化学");
    chemist->resize(400,150);
    computer->setParent(this);
    computer->setText("计算机");
    computer->resize(400,150);
    physic->setParent(this);
    physic->setText("物理");
    physic->resize(400,150);
    biology->setParent(this);
    biology->setText("生物");
    biology->resize(400,150);
    back->setParent(this);
    back->setText("打印成绩并返回");
    back->resize(400,150);

    math->move(70,50);
    chemist->move(70,300);
    computer->move(70,550);
    physic->move(700,50);
    biology->move(700,300);
    back->move(700,550);

    viewbiology = new ViewBiology;
    viewchemist = new ViewChemist;
    viewcomputer = new ViewComputer;
    viewmath = new ViewMath;
    viewphysics = new ViewPhysics;

    connect(math,&QPushButton::clicked,[=](){
        this->hide();
        viewmath->show();
    });

    connect(chemist,&QPushButton::clicked,[=](){
        this->hide();
        viewchemist->show();
    });

    connect(computer,&QPushButton::clicked,[=](){
        this->hide();
        viewcomputer->show();
    });

    connect(physic,&QPushButton::clicked,[=](){
        this->hide();
        viewphysics->show();
    });

    connect(biology,&QPushButton::clicked,[=](){
        this->hide();
        viewbiology->show();
    });


}
