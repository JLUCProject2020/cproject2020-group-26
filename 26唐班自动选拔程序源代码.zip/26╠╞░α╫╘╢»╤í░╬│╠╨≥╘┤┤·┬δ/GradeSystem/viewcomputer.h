#ifndef VIEWCOMPUTER_H
#define VIEWCOMPUTER_H

#include <QWidget>

class ViewComputer : public QWidget
{
    Q_OBJECT
public:
    explicit ViewComputer(QWidget *parent = nullptr);

signals:

public slots:
};

#endif // VIEWCOMPUTER_H