#ifndef WRICHEM_H
#define WRICHEM_H

#include <QWidget>

class WriChem : public QWidget
{
    Q_OBJECT
public:
    explicit WriChem(QWidget *parent = nullptr);

signals:

public slots:
};

#endif // WRICHEM_H