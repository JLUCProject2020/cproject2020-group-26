#include "wribio.h"

WriBio::WriBio(QWidget *parent) : QWidget(parent)
{

}
