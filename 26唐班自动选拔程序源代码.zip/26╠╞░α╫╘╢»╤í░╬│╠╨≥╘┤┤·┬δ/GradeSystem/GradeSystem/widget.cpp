#include "widget.h"
#include "ui_widget.h"
#include<QPushButton>
#include"bishi.h"

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
    setFixedSize(1200,800);
    setWindowTitle("唐班自动化选拔系统");

    QPushButton * signin = new QPushButton;
    signin->setParent(this);
    signin->setText("登录");
    signin->move(530,650);
    signin->resize(90,50);

    choose = new Choose;


    connect(signin,&QPushButton::clicked,[=](){
        this->hide();
        choose->show();
    });

}

Widget::~Widget()
{
    delete ui;
}
