#ifndef WRICOMPU_H
#define WRICOMPU_H

#include <QWidget>

class WriCompu : public QWidget
{
    Q_OBJECT
public:
    explicit WriCompu(QWidget *parent = nullptr);

signals:

public slots:
};

#endif // WRICOMPU_H