#ifndef VIEWMATH_H
#define VIEWMATH_H

#include <QWidget>

class ViewMath : public QWidget
{
    Q_OBJECT
public:
    explicit ViewMath(QWidget *parent = nullptr);

signals:

public slots:
};

#endif // VIEWMATH_H