#include "wrichem.h"
#include<QLabel>
#include<QLineEdit>
#include"source.h"
#include<QString>
#include<QDebug>
#include<QPushButton>

WriChem::WriChem(QWidget *parent) : QWidget(parent)
{
    setFixedSize(1200,800);
    setWindowTitle("笔试化学");

    QLabel * title = new QLabel;
    title->setParent(this);
    title->setText("化学");
    title->move(20,30);
    QLabel * lab1 = new QLabel;
    lab1->setParent(this);
    lab1->setText("学号：");
    lab1->move(20,50);
    QLabel * lab2 = new QLabel;
    lab2->setParent(this);
    lab2->setText("化学分数：");
    lab2->move(20,100);
    QLabel * lab3 = new QLabel;
    lab3->setParent(this);
    lab3->setText("数学分数：");
    lab3->move(20,200);
    QLabel * lab4 = new QLabel;
    lab4->setParent(this);
    lab4->setText("生物分数：");
    lab4->move(20,300);
    QLabel * lab5 = new QLabel;
    lab5->setParent(this);
    lab5->setText("综合分数：");
    lab5->move(20,400);
    QLabel * lab6 = new QLabel;
    lab6->setParent(this);
    lab6->setText("英语分数：");
    lab6->move(20,500);

    QLineEdit * idnum = new QLineEdit;
    idnum->setParent(this);
    idnum->move(130,50);
    QLineEdit * chemistrynum = new QLineEdit;
    chemistrynum->setParent(this);
    chemistrynum->move(130,100);
    QLineEdit * mathnum = new QLineEdit;
    mathnum->setParent(this);
    mathnum->move(130,200);
    QLineEdit * biologynum = new QLineEdit;
    biologynum->setParent(this);
    biologynum->move(130,300);
    QLineEdit * allnum = new QLineEdit;
    allnum->setParent(this);
    allnum->move(130,400);
    QLineEdit * engnum = new QLineEdit;
    engnum->setParent(this);
    engnum->move(130,500);


    QPushButton * btn1 = new QPushButton;
    btn1->setParent(this);
    btn1->setText("下一个");
    btn1->move(800,700);
    QPushButton * btn2 = new QPushButton;
    btn2->setParent(this);
    btn2->setText("结束");
    btn2->move(950,700);


    Chemist* chemiststudent = new Chemist[30];
    static int k=0;

    connect(btn1,&QPushButton::clicked,[=](){
        int str1 = idnum->text().toInt();
        qDebug()<<str1;
        int str2 = chemistrynum->text().toInt();
        qDebug()<<str2;
        int str3 = mathnum->text().toInt();
        int str4 = biologynum->text().toInt();
        int str5 = allnum->text().toInt();
        int str6 = engnum->text().toInt();

        chemiststudent[k].id=str1;
        chemiststudent[k].chemist_Score=str2;
        chemiststudent[k].math_Score=str3;
        chemiststudent[k].biology_Score=str4;
        chemiststudent[k].all_Score=str5;
        chemiststudent[k].english_Score=str6;
        k++;

        idnum->setText(NULL);
        chemistrynum->setText(NULL);
        mathnum->setText(NULL);
        biologynum->setText(NULL);
        allnum->setText(NULL);
        engnum->setText(NULL);
    });

    connect(btn2,&QPushButton::clicked,[=](){
        int h,j,temp;
        for(h=0;h<k-1;h++)
            for(j=0;j<k-h-1;j++){
                if(chemiststudent[j].all_Score>chemiststudent[j+1].all_Score){
                    temp=chemiststudent[j].all_Score;
                    chemiststudent[j].all_Score=chemiststudent[j+1].all_Score;
                    chemiststudent[j+1].all_Score=temp;
                }
            }

        for(h=0;h<k*0.3;h++){
            qDebug()<<chemiststudent[h].id;
        }
        this->close();
    });



}
