#ifndef WRIPHY_H
#define WRIPHY_H

#include <QWidget>

class WriPhy : public QWidget
{
    Q_OBJECT
public:
    explicit WriPhy(QWidget *parent = nullptr);

signals:

public slots:
};

#endif // WRIPHY_H