#include "wricompu.h"

WriCompu::WriCompu(QWidget *parent) : QWidget(parent)
{

}
