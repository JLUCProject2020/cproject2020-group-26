#include<iostream>
#include<cstring>
using namespace std;

class Math{
    public:
        int id;
        int math_Score;
        int physics_Score;
        int english_Score;
        int all_Score;
        int view_Score;
        int view_English;
        int view_All;
        Math(int i=0,int m=0,int p=0,int e=0,int vs=0,int ve=0);
};
class Physics{
    public:
        int id;
        int physics_Score;
        int math_Score;
        int english_Score;
        int all_Score;
        int view_Score;
        int view_English;
        int view_All;
        Physics(int i=0,int p=0,int m=0,int e=0,int vs=0,int ve=0);
};
class Chemist{
    public:
        int id;
        int chemist_Score;
        int biology_Score;
        int math_Score;
        int english_Score;
        int all_Score;
        int view_Score;
        int view_English;
        int view_All;

        Chemist(int i=0,int c=0,int b=0,int m=0,int e=0,int a=0,int vs=0,int ve=0);
};
class Biology{
    public:
        int id;
        int chemist_Score;
        int biology_Score;
        int math_Score;
        int english_Score;
        int all_Score;
        int view_Score;
        int view_English;
        int view_All;

        Biology(int i=0,int c=0,int b=0,int m=0,int e=0,int vs=0,int ve=0);
};
class Computer{
    public:
        int id;
        int computer_Score;
        int math_Score;
        int physics_Score;
        int english_Score;
        int all_Score;
        int view_Score;
        int view_English;
        int view_All;

        Computer(int i=0,int c=0,int m=0,int p=0,int e=0,int vs=0,int ve=0);
};

