#ifndef WRIBIO_H
#define WRIBIO_H

#include <QWidget>

class WriBio : public QWidget
{
    Q_OBJECT
public:
    explicit WriBio(QWidget *parent = nullptr);

signals:

public slots:
};

#endif // WRIBIO_H