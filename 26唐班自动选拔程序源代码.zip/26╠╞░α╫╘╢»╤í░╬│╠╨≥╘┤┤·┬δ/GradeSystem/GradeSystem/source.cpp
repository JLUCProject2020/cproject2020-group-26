#include "source.h"
#include<iostream>
using namespace std;

Math::Math(int i,int m,int p,int e,int vs,int ve){
    id=i;
    math_Score=m;
    physics_Score=p;
    english_Score=e;
    all_Score=math_Score+physics_Score+english_Score;
    view_Score=vs;
    view_English=ve;
    view_All=view_Score+view_English;
}
Physics::Physics(int i,int p,int m,int e,int vs,int ve){
    id=i;
    physics_Score=p;
    math_Score=m;
    english_Score=e;
    all_Score=physics_Score+math_Score+english_Score;
    view_Score=vs;
    view_English=ve;
    view_All=view_Score+view_English;
}
Chemist::Chemist(int i,int c,int b,int m,int e,int a,int vs,int ve){
    id=i;
    chemist_Score=c;
    biology_Score=b;
    math_Score=m;
    english_Score=e;
    all_Score=chemist_Score+biology_Score+math_Score+english_Score;
    view_Score=vs;
    view_English=ve;
    view_All=view_Score+view_English;
}
Biology::Biology(int i,int c,int b,int m,int e,int vs,int ve){
    id=i;
    chemist_Score=c;
    biology_Score=b;
    math_Score=m;
    english_Score=e;
    all_Score=chemist_Score+biology_Score+math_Score+english_Score;
    view_Score=vs;
    view_English=ve;
    view_All=view_Score+view_English;
}
Computer::Computer(int i,int c,int m,int p,int e,int vs,int ve){
    id=i;
    computer_Score=c;
    math_Score=m;
    physics_Score=p;
    english_Score=e;
    all_Score=computer_Score+math_Score+physics_Score+english_Score;
    view_Score=vs;
    view_English=ve;
    view_All=view_Score+view_English;
}


