#ifndef WRIMATH_H
#define WRIMATH_H

#include <QWidget>

class WriMath : public QWidget
{
    Q_OBJECT
public:
    explicit WriMath(QWidget *parent = nullptr);

signals:

public slots:
};

#endif // WRIMATH_H