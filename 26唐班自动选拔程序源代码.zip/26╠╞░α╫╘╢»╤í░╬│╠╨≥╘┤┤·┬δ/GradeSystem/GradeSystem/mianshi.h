#ifndef MIANSHI_H
#define MIANSHI_H

#include <QWidget>

class MianShi : public QWidget
{
    Q_OBJECT
public:
    explicit MianShi(QWidget *parent = nullptr);

signals:

public slots:
};

#endif // MIANSHI_H