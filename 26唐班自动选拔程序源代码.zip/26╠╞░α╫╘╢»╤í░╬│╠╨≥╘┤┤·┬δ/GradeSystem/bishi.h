#ifndef BISHI_H
#define BISHI_H

#include <QWidget>
#include"wribio.h"
#include"wrichem.h"
#include"wricompu.h"
#include"wrimath.h"
#include"wriphy.h"

class BiShi : public QWidget
{
    Q_OBJECT
public:
    explicit BiShi(QWidget *parent = nullptr);

    WriBio * wribio = NULL;
    WriChem * wrichem = NULL;
    WriCompu * wricompu = NULL;
    WriMath * wrimath = NULL;
    WriPhy * wriphy = NULL;

signals:

public slots:
};

#endif // BISHI_H
