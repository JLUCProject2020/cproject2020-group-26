#include "choose.h"
#include<QPushButton>
#include"bishi.h"
#include"mianshi.h"
#include"widget.h"

Choose::Choose(QWidget *parent) : QWidget(parent)
{
    setWindowTitle("选择页面");
    setFixedSize(1200,800);

    QPushButton * write = new QPushButton;
    write->setParent(this);
    write->setText("笔试");
    write->resize(300,200);
    write->move(150,300);
    QPushButton * view = new QPushButton;
    view->setParent(this);
    view->setText("面试");
    view->resize(300,200);
    view->move(700,300);

     bishi = new BiShi;
     mianshi = new MianShi;

    connect(write,&QPushButton::clicked,[=](){
        this->hide();
        bishi->show();
    });
    connect(view,&QPushButton::clicked,[=](){
        this->hide();
        mianshi->show();
    });

}
